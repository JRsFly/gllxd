/*************************************************************************
	> File Name: udp_server.h
	> Author: suyelu 
	> Mail: suyelu@126.com
	> Created Time: Thu 09 Jul 2020 11:15:45 AM CST
 ************************************************************************/

#ifndef _UDP_SERVER_H
#define _UDP_SERVER_H
int socket_create_udp(int port);
#endif
